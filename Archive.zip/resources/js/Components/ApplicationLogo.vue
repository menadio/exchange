<template>
    <h1 class="text-red-700 font-black text-6xl text-center">FMCBDC</h1>
    <p class="mt-8 text-red-700 uppercase tracking-widest text-center">
        Bureau De Change Book Keeping
    </p>
</template>
